package avaliacoes.A2.simulado.maxTurismo;

public interface VendaDeTurismoIF {
    public double getPreco();
    public String getDescricao();

}
